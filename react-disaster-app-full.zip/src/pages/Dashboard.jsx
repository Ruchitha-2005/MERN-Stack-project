import React, { useState, useEffect } from "react";
import { Header } from "../components/Header";
import { FeatureCard } from "../components/FeatureCard";
import { EmergencyButton } from "../components/EmergencyButton";
import { Map, Users, Radio, BookOpen, Shield } from "lucide-react";

export default function Dashboard() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [emergencyActive, setEmergencyActive] = useState(false);

  useEffect(() => {
    const handleOnlineStatus = () => setIsOnline(navigator.onLine);
    window.addEventListener("online", handleOnlineStatus);
    window.addEventListener("offline", handleOnlineStatus);
    return () => {
      window.removeEventListener("online", handleOnlineStatus);
      window.removeEventListener("offline", handleOnlineStatus);
    };
  }, []);

  const handleEmergencyClick = () => {
    setEmergencyActive(!emergencyActive);
    if (!emergencyActive) {
      setTimeout(() => {
        alert("🚨 Emergency alert sent to nearby volunteers and services!");
        setEmergencyActive(false);
      }, 3000);
    }
  };

  const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}");

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isOnline={isOnline} userName={currentUser.fullName || "Guest"} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {currentUser.fullName || "Guest"}</h2>
          <p className="text-gray-600">Stay connected with your community's safety network</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <FeatureCard title="Interactive Safe Zone Map" description="View real-time safe zones and evacuation routes." icon={<Map className="w-6 h-6 text-white" />} color="bg-gradient-to-r from-blue-500 to-blue-600" onClick={() => alert("Opening map...")} />
              <FeatureCard title="Volunteer Coordination" description="Connect with local volunteers and request help." icon={<Users className="w-6 h-6 text-white" />} color="bg-gradient-to-r from-green-500 to-green-600" onClick={() => alert("Opening volunteer hub...")} />
              <FeatureCard title="Emergency Communications" description="Receive push notifications and urgent updates." icon={<Radio className="w-6 h-6 text-white" />} color="bg-gradient-to-r from-purple-500 to-purple-600" onClick={() => alert("Opening communications...")} />
              <FeatureCard title="Resource Directory" description="Find shelters, medical facilities, and supplies." icon={<BookOpen className="w-6 h-6 text-white" />} color="bg-gradient-to-r from-orange-500 to-orange-600" onClick={() => alert("Opening resources...")} />
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Emergency Alert</h3>
              <EmergencyButton onClick={handleEmergencyClick} isActive={emergencyActive} />
              <p className="text-xs text-gray-500 mt-3 text-center">Press to send alert to nearby volunteers & authorities</p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Safety Status</h3>
              <div className="flex items-center space-x-3 p-4 rounded-lg bg-green-50 border border-green-200">
                <div className="p-2 rounded-full bg-green-100">
                  <Shield className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-medium text-green-800">You're Safe</p>
                  <p className="text-sm text-green-600">Last updated 2h ago</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
