import React from 'react';
export default function Guest(){return(<div>Guest Page</div>)}
