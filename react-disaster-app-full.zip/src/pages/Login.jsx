import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'

export default function Login() {
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')
  const navigate = useNavigate()

  const handleLogin = (e) => {
    e.preventDefault()
    const users = JSON.parse(localStorage.getItem('users') || '[]')
    const user = users.find(u =>
      (u.email.toLowerCase() === identifier.toLowerCase() || u.phone === identifier) &&
      u.password === password
    )
    if (!user) {
      alert('Invalid credentials. Please check email/phone and password.')
      return
    }
    localStorage.setItem('currentUser', JSON.stringify({
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      phone: user.phone
    }))
    alert('Login successful! Redirecting to dashboard...')
    navigate('/dashboard')
  }

  return (
    <div className="container">
      <h2>🔐 Login</h2>
      <form onSubmit={handleLogin}>
        <input type="text" placeholder="📧 Email or Phone" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required />
        <input type="password" placeholder="🔒 Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit" className="btn">Login</button>
      </form>
      <p style={{marginTop:20, color:'#7f8c8d'}}>
        Don&apos;t have an account?{' '}
        <Link to="/signup" style={{color:'#3498db', textDecoration:'none', fontWeight:500}}>Sign Up</Link>
      </p>
      <Link to="/" className="back-link">← Back to Home</Link>
    </div>
  )
}
