import React from 'react';
export default function Emergency(){return(<div>Emergency Page</div>)}
