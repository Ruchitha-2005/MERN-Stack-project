import React from "react";

export function FeatureCard({ title, description, icon, color, onClick }) {
  return (
    <div onClick={onClick} className={`cursor-pointer ${color} rounded-xl p-6 text-white shadow-md hover:shadow-lg transition`}>
      <div className="flex items-center space-x-3 mb-4">
        <div className="p-2 bg-white/20 rounded-lg">{icon}</div>
        <h3 className="font-bold text-lg">{title}</h3>
      </div>
      <p className="text-sm">{description}</p>
    </div>
  );
}
