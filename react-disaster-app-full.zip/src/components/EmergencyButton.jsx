import React from "react";

export function EmergencyButton({ onClick, isActive }) {
  return (
    <button
      onClick={onClick}
      className={`w-full py-4 rounded-lg font-bold text-white text-lg shadow-md transition ${
        isActive ? "bg-red-600 animate-pulse" : "bg-gradient-to-r from-red-500 to-red-700 hover:opacity-90"
      }`}
    >
      {isActive ? "Sending Alert..." : "🚨 Send SOS Alert"}
    </button>
  );
}
