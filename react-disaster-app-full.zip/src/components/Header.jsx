import React from "react";
import { Wifi, WifiOff, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function Header({ isOnline, userName }) {
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem("currentUser");
    navigate("/login");
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">DR</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">DisasterResponse</h1>
              <p className="text-xs text-gray-500">Community Safety Network</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {isOnline ? (
                <Wifi className="w-5 h-5 text-green-500" />
              ) : (
                <WifiOff className="w-5 h-5 text-red-500" />
              )}
              <span className={`text-sm font-medium ${isOnline ? "text-green-600" : "text-red-600"}`}>
                {isOnline ? "Online" : "Offline"}
              </span>
            </div>

            <span className="text-sm font-medium text-gray-700">{userName}</span>

            <button onClick={handleLogout} className="flex items-center space-x-1 text-sm text-red-600 hover:text-red-800">
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
